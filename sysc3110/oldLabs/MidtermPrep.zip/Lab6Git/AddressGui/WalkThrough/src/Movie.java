public class Movie 
{

	public Movie(String movieName) 
	{
	}

}