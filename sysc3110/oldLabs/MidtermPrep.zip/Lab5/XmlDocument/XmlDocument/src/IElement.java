
public interface IElement 
{
	
	public String getName();
	
	public String ToString();

}
