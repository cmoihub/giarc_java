
public class BuddyInfo {
	
	public static String FirstName = "Jas";

	public static String getFirstName() {
		return FirstName;
	}

	public static void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public static void main(String[] args)
	{
		System.out.print("Hello " + getFirstName());
		
	}

}
