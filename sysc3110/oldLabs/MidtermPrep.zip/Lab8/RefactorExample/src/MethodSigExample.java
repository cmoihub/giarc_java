public class MethodSigExample
{
	public int test(String s, int i, String n)
	{
		int x = i + s.length();
		return x;
	}
}