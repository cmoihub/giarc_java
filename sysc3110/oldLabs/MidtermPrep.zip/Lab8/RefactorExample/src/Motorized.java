
public interface Motorized {

	String getMotor();

	void setMotor(String string);

}