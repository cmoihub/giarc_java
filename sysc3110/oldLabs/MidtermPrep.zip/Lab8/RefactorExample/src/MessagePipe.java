
public class MessagePipe {

	
	public void send(IBag bag)
	{
		
	}
}
