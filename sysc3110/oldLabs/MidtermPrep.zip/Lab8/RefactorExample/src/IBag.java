
public interface IBag {
	public static String msg = "";

	public Object get();

	public void set(Object message);
}
