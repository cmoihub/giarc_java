
final class BagImpl implements IBag {
	Object o;

	public Object get()
	{
		return o;
	}

	public void set(Object o)
	{
		this.o = o;
	}
}