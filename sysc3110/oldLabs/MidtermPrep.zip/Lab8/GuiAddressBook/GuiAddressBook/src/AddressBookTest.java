import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AddressBookTest
{
	AddressBook book = null;


	@Before
	public void setUp() throws Exception 
	{
		book = new AddressBook();
	}

	@After
	public void tearDown() throws Exception
	{
		book = null;
	}

	@Test
	public void testAddressBookInitializesCorrectly() 
	{
		AddressBook firstBook = new AddressBook();
		assertTrue("AddressBook should not be null, expect true", firstBook != null);
		assertTrue("AddressBook should be empty, expect true", firstBook.Size() == 0);
	}

	@Test
	public void testAddBuddyStringStringInt() 
	{
		assertTrue("Should add buddy successfully", book.AddBuddy("SomeFirstName", "SomeLastName", 2));
	}

	@Test
	public void testAddBuddyBuddyInfo() 
	{
		BuddyInfo buddy = new BuddyInfo("ThisFirstName", "ThisLastName", 1);
		assertTrue("Should add buddy successfully", book.AddBuddy(buddy));
	}

	@Test
	public void testRemoveBuddyByFirstNameSuccessfully() 
	{
		String firstName = "MyFirstName";
		assertTrue("Should add buddy successfully", book.AddBuddy(firstName, "MyLastName", 1));
		assertTrue("Should successfully remove buddy", book.RemoveBuddy(firstName));
	}

	@Test
	public void testRemoveBuddyByFirstNameDoesNotFindBuddy() 
	{
		String firstName = "MyFirstName";
		assertTrue("Should add buddy successfully", book.AddBuddy(firstName, "MyLastName", 1));
		assertFalse("Should not find buddy on non-empty list", book.RemoveBuddy("NameThatDoesNotExist"));
	}

	@Test
	public void testRemoveBuddyByFirstNameDoesNotFindBuddyInEmptyList() 
	{
		assertTrue("AddressBook should be empty", book.Size() == 0);
		assertFalse("Should not find buddy on empty list", book.RemoveBuddy("NameThatDoesNotExist"));
	}

	@Test
	public void testSize() 
	{
		//new List
		assertEquals("Size should be '0'", 0, book.Size() );
		//add one
		book.AddBuddy("MyFirstName", "MyLastName", 1);
		assertEquals("Size should be '1'", 1, book.Size() );
		//add one
		book.AddBuddy("YourFirstName", "YourLastName", 2);
		assertEquals("Size should be '2'", 2, book.Size() );
		//remove one
		book.RemoveBuddy("MyFirstName");
		assertEquals("Size should be '1'", 1, book.Size() );
		//remove one
		book.RemoveBuddy("YourFirstName");
		assertEquals("Size should be '0'", 0, book.Size() );
	}

	@Test
	public void testClearWorkWhenStartEmpty() 
	{
		assertEquals("Size should be '0'", 0, book.Size() );
		book.Clear();
		assertEquals("Size should be '0'", 0, book.Size() );
	}

	@Test
	public void testClearWorksWhenBookHasEntries() 
	{
		assertEquals("Size should be '0'", 0, book.Size() );
		//add entries
		book.AddBuddy("MyFirstName", "MyLastName", 1);
		book.AddBuddy("YourFirstName", "YourLastName", 2);
		assertNotEquals("Size should NOT be '0'", 0, book.Size() );
		book.Clear();
		assertEquals("Size should be '0'", 0, book.Size() );
	}

}
