
public class BuddyInfo 
{

	private String FirstName = "";
	private String LastName = "";
	private int Age = 0;
	private int Id = 0;

	public BuddyInfo(String firstName, String lastName, int id)
	{
		FirstName = firstName;
		LastName = lastName;
		Id = id;
	}

	public BuddyInfo(BuddyInfo buddy)
	{
		if(buddy != null)
		{
			FirstName = buddy.GetFirstName();
			LastName = buddy.GetLastName();
			Id = buddy.GetId();
		}
	}

	public String GetFirstName() 
	{
		return FirstName;
	}

	public void SetFirstName(String firstName)
	{
		if(firstName != null)
		{
			FirstName = firstName;
		}
	}

	public String GetLastName() 
	{
		return LastName;
	}

	public void SetLastName(String lastName)
	{
		if(lastName != null)
		{
			LastName = lastName;
		}
	}

	public int GetId() 
	{
		return Id;
	}

	public void SetId(int id)
	{
		if(id >= 0)
		{
			Id = id;
		}
	}

	public String greet()
	{
		return "Hello, I am " + GetFirstName() + " " + GetLastName();
	}

	public void SetAge(int newAge)
	{
		if(newAge > 0)
		{
			Age = newAge;
		}
	}

	public int GetAge()
	{
		return Age;
	}

	public boolean IsOver18()
	{
		return (Age > 18);
	}

	@Override
	public String toString()
	{
		return GetId() + "%" + GetFirstName() + "%" + GetLastName() + "\n";
	}

	public static void main(String[] args)
	{
		/*BuddyInfo buddy = new BuddyInfo("Jas");
		System.out.print("Hello " + buddy.GetFirstName());*/
	}
	
	public static BuddyInfo importBuddyInfo(String string)
	{
		try{
			String[] details = string.split("%");
			if(details.length == 3)
			{
				BuddyInfo info = new BuddyInfo(details[1], details[2], Integer.parseInt(details[0]));
				return info;
			}
		}
		catch(Exception ex)
		{
		}
		return null;
	}

}
