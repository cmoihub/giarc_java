import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BuddyInfoTest {

	BuddyInfo buddy = null;
	private String originalFirstName = "OriginalFirst";
	private String originalLastName = "OriginalLast";
	private int originalId = 1;

	@Before
	public void setUp() throws Exception 
	{
		buddy = new BuddyInfo(originalFirstName, originalLastName, originalId);
	}

	@After
	public void tearDown() throws Exception 
	{
		buddy = null;
	}

	@Test
	public void testBuddyInfoStringStringIntConstructsSuccessfully() 
	{
		BuddyInfo newBuddyInfo = new BuddyInfo(originalFirstName, originalLastName, originalId);
		assertTrue("BuddyInfo should not be null, condition should be true", newBuddyInfo != null);
	}

	@Test
	public void testBuddyInfoBuddyInfoClonesSuccessfully()
	{
		BuddyInfo clone = new BuddyInfo(buddy);
		assertEquals("Expect both first names to be '" + originalFirstName + "'", buddy.GetFirstName(), clone.GetFirstName());
		assertEquals("Expect both last names to be '" + originalLastName + "'", buddy.GetLastName(), clone.GetLastName());
		assertEquals("Expect both ids to be '" + originalId + "'", buddy.GetId(), clone.GetId());
	}
	
	@Test
	public void testBuddyInfoBuddyInfoConstructorPassedNull_ThenSetToDefaults()
	{
		BuddyInfo clone = new BuddyInfo(null);
		assertEquals("Expect both first names to be ''", "", clone.GetFirstName());
		assertEquals("Expect both last names to be ''", "", clone.GetLastName());
		assertEquals("Expect both ids to be '" + originalId + "'", 0, clone.GetId());
	}

	@Test
	public void testGetFirstName() 
	{
		assertEquals("Expect the first name to be '" + originalFirstName + "'", originalFirstName, buddy.GetFirstName());
	}

	@Test
	public void testSetFirstName() 
	{
		String newName = "newFirstName";
		buddy.SetFirstName(newName);
		assertEquals("Expect the first name to be '" + newName + "'", newName, buddy.GetFirstName());
	}

	@Test
	public void testSetFirstNameWithInvalidParameter() 
	{
		String newName = null;
		buddy.SetFirstName(newName);
		assertEquals("Expect the first name to be '" + originalFirstName + "'", originalFirstName, buddy.GetFirstName());
	}

	@Test
	public void testGetLastName() 
	{
		assertEquals("Expect the last name to be '" + originalLastName + "'", originalLastName, buddy.GetLastName());
	}

	@Test
	public void testSetLastName() 
	{
		String newName = "newLastName";
		buddy.SetLastName(newName);
		assertEquals("Expect the last name to be '" + newName + "'", newName, buddy.GetLastName());
	}

	@Test
	public void testSetLastNameWithInvalidParameter() 
	{
		String newName = null;
		buddy.SetLastName(newName);
		assertEquals("Expect the first name to be '" + originalLastName + "'", originalLastName, buddy.GetLastName());
	}

	@Test
	public void testGetId() 
	{
		assertEquals("Expect the id to be '" + originalId + "'", originalId, buddy.GetId());
	}

	@Test
	public void testSetIdSuccessfully() 
	{
		int newId = 5;
		buddy.SetId(newId);
		assertEquals("Expect the id to be '" + newId + "'", newId, buddy.GetId());
	}

	@Test
	public void testSetIdInvalidArgument() 
	{
		int newId = -1;
		buddy.SetId(newId);
		assertNotEquals("Expect the id to NOT be '" + newId + "'", newId, buddy.GetId());
		assertEquals("Expect the id to be '" + originalId + "'", originalId, buddy.GetId());
	}

	@Test
	public void testSetIdSuccessfulEdgeCase() 
	{
		int newId = 0;
		buddy.SetId(newId);
		assertEquals("Expect the id to be '" + newId + "'", newId, buddy.GetId());
	}

	@Test
	public void testGreet() 
	{
		assertEquals("The greeting should be 'Hello, I am " + originalFirstName + " " + originalLastName + "'", 
				"Hello, I am " + originalFirstName + " " + originalLastName, buddy.greet());
	}

	@Test
	public void testGetAge() 
	{
		assertEquals("Expect the age to be '0'", 0, buddy.GetAge());
	}

	@Test
	public void testSetAgeSuccessfully() 
	{
		int newAge = 22;
		buddy.SetAge(newAge);
		assertEquals("Expect the age to be '" + newAge + "'", newAge, buddy.GetAge());
	}

	@Test
	public void testSetAgeWithInvalidArgument() 
	{
		int newAge = -1;
		buddy.SetAge(newAge);
		assertEquals("Expect the age to be '0'", 0, buddy.GetAge());
	}

	@Test
	public void testIsOver18ReturnsTrue() 
	{
		buddy.SetAge(20);
		assertTrue("With age set to 22, should be true.", buddy.IsOver18());
	}

	@Test
	public void testIsOver18ReturnsFalse() 
	{
		buddy.SetAge(17);
		assertFalse("With age set to 17, should be false.", buddy.IsOver18());
	}

	@Test
	public void testIsOver18ReturnsFalseWhenAt18() 
	{
		buddy.SetAge(18);
		assertFalse("With age set to 18, should be false.", buddy.IsOver18());
	}

}
