import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.swing.*;

public class GuiBook  extends JFrame implements ActionListener
{
	private static final long serialVersionUID = 281173259372442797L;
	private AddressBook book;
	int id = 0;
	public GuiBook()
	{
		JFrame jf = new JFrame("AddressBook");
		jf.setSize(400, 400);
		JMenuBar bar = new JMenuBar();
		jf.setJMenuBar(bar);

		JMenu addressBook = new JMenu( "AddressBook" );
		bar.add( addressBook );
		JMenuItem item;
		item = new JMenuItem ( "Create" );
		item.addActionListener( this );
		addressBook.add(item);
		item = new JMenuItem ( "Display" );
		item.addActionListener( this );
		addressBook.add(item);
		item = new JMenuItem ( "Export" );
		item.addActionListener( this );
		addressBook.add(item);
		item = new JMenuItem ( "Import" );
		item.addActionListener( this );
		addressBook.add(item);
		
		JMenu buddyInfo = new JMenu( "BuddyInfo" );
		bar.add( buddyInfo );
		item = new JMenuItem ( "Add" );
		item.addActionListener( this );
		buddyInfo.add(item);

		jf.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		if(arg0.getActionCommand() == "Create")
		{
			book = new AddressBook();
		}
		else if(arg0.getActionCommand() == "Display")
		{
			AddressBookView view = new AddressBookView(book);
		}
		else if(arg0.getActionCommand() == "Add")
		{
			String firstName = "";
			while(firstName == null || firstName == "")
			{
				firstName = (String)JOptionPane.showInputDialog(
						this,
						"Enter the first name\n",
						"Customized Dialog", JOptionPane.PLAIN_MESSAGE,
						null,
						null,
						"");
			}

			String lastName = "";
			while(lastName == null || lastName == "")
			{
				lastName = (String)JOptionPane.showInputDialog(
						this,
						"Enter the last name\n",
						"Customized Dialog", JOptionPane.PLAIN_MESSAGE,
						null,
						null,
						"");
			}

			book.AddBuddy(firstName, lastName, id);
			id++;
		}
		else if(arg0.getActionCommand() == "Export")
		{
			try {
				List<String> content = book.getBuddyInfoDetails();

				File file = new File(System.getProperty("user.dir") + "/export.txt");
				// if file doesnt exists, then create it
				if (!file.exists()) {
					file.createNewFile();
				}

				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				BufferedWriter bw = new BufferedWriter(fw);
				
				for (String info : content) {
					bw.write(info);
					bw.newLine();
				}
				bw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else if(arg0.getActionCommand() == "Import")
		{
			try (BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/export.txt")))
			{
				String sCurrentLine;

				while ((sCurrentLine = br.readLine()) != null) {
					BuddyInfo newInfo = BuddyInfo.importBuddyInfo(sCurrentLine);
					if(newInfo != null)	book.AddBuddy(newInfo);
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else
		{
			try 
			{
				throw new Exception("Command --" + arg0.getActionCommand() + "-- is not implemented.");
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}

		}
	}

}
