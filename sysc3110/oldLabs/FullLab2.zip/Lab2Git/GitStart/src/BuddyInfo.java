
public class BuddyInfo 
{
	
	private String FirstName = "";
	
	public BuddyInfo(String firstName)
	{
		FirstName = firstName;
	}

	public String GetFirstName() 
	{
		return FirstName;
	}

	public void SetFirstName(String firstName)
	{
		FirstName = firstName;
	}

	public static void main(String[] args)
	{
		BuddyInfo buddy = new BuddyInfo("Jas");
		System.out.print("Hello " + buddy.GetFirstName());
	}

}
