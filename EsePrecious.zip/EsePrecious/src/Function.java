public interface Function
{
  
  //Function method that returns the value of a function
  public double returnValue(double x, double y);
  
}